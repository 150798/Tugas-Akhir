package com.example.latihan123;

public class DataSaklar {
    // inisialisasi saklar
    private String S1, S2, S3, S4, S5, S6, S7;

    public DataSaklar(String s1, String s2, String s3, String s4, String s5, String s6, String s7){

        this.S1 = s1;
        this.S2 = s2;
        this.S3 = s3;
        this.S4 = s4;
        this.S5 = s5;
        this.S6 = s6;
        this.S7 = s7;
    }

    public String getS1() {
        return S1;
    }

    public void setS1(String s1) {
        S1 = s1;
    }

    public String getS2() {
        return S2;
    }

    public void setS2(String s2) {
        S2 = s2;
    }

    public String getS3() {
        return S3;
    }

    public void setS3(String s3) {
        S3 = s3;
    }

    public String getS4() {
        return S4;
    }

    public void setS4(String s4) {
        S4 = s4;
    }

    public String getS5() {
        return S5;
    }

    public void setS5(String s5) {
        S5 = s5;
    }

    public String getS6() {
        return S6;
    }

    public void setS6(String s6) {
        S6 = s6;
    }

    public String getS7() {
        return S7;
    }

    public void setS7(String s7) {
        S7 = s7;
    }
}

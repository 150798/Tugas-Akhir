package com.example.latihan123;

public class ServerList {

    private static String baseURL = "https://smartoffice16.000webhostapp.com/";

    public static String urlMaster = "https://tugasakhir-ba915.firebaseio.com/data.json";
    public static String urlSimpanStatusSaklar = baseURL + "insert.php";
    public static String urlHistoryUpdate = baseURL + "history.php";
    public static String urlLogin = baseURL + "login.php";
}
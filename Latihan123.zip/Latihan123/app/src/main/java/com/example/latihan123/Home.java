package com.example.latihan123;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Home extends AppCompatActivity {
    private FirebaseDatabase mDatabase;
    private final String TAG="Home1";
    private String urlMaster = ServerList.urlMaster;
    private String urlSimpanStatusSaklar = ServerList.urlSimpanStatusSaklar;
    private String valueS1="0";
    private String valueS2="0";
    private String valueS3="0";
    private String valueS4="0";
    private String valueS5="0";
    private String valueS6="0";
    private String valueS7="0";
    private Button btnperangkatA, btnperangkatB,btnperangkatC, btnperangkatD, btnperangkatE, btnallon, btnalloff;
    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) { //onCreate
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        mDatabase = FirebaseDatabase.getInstance();
        session=new SessionManager(this);
        setTitle("Home");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.iconhome);

        //mengambil data status saklar awal
        getStatusSaklar();

        //inisialisasi tombol yg ada di view
        btnperangkatA = (Button) findViewById(R.id.perangkatA);
        btnperangkatB = (Button) findViewById(R.id.perangkatB);
        btnperangkatC = (Button) findViewById(R.id.perangkatC);
        btnperangkatD = (Button) findViewById(R.id.perangkatD);
        btnperangkatE = (Button) findViewById(R.id.perangkatE);
        btnallon = (Button) findViewById(R.id.allon);
        btnalloff = (Button) findViewById(R.id.alloff);

        // event ketika salah 1 tombol di klik dan sekalian ngubah di database
        btnperangkatA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Jika saklar bernilai 1 maka update ke nilai 0, begitu pula sebaliknya
                if(valueS1.equals("0")){
                    valueS1="1";

                }
                else {
                    valueS1="0";
                }
                updateStatusSaklar();
                SimpanStatusSaklar("S1", valueS1);
            }
        });

        btnperangkatB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Jika saklar bernilai 1 maka update ke nilai 0, begitu pula sebaliknya
                if(valueS2.equals("0")){
                    valueS2="1";

                }
                else {
                    valueS2="0";
                }
                updateStatusSaklar();
                SimpanStatusSaklar("S2", valueS2);

            }
        });

        btnperangkatC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Jika saklar bernilai 1 maka update ke nilai 0, begitu pula sebaliknya
                if(valueS3.equals("0")){
                    valueS3="1";

                }
                else {
                    valueS3="0";
                }
                updateStatusSaklar();
                SimpanStatusSaklar("S3", valueS3);

            }
        });

        btnperangkatD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Jika saklar bernilai 1 maka update ke nilai 0, begitu pula sebaliknya
                if(valueS4.equals("0")){
                    valueS4="1";

                }
                else {
                    valueS4="0";
                }
                updateStatusSaklar();
                SimpanStatusSaklar("S4", valueS4);

            }
        });

        btnperangkatE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Jika saklar bernilai 1 maka update ke nilai 0, begitu pula sebaliknya
                if(valueS5.equals("0")){
                    valueS5="1";

                }
                else {
                    valueS5="0";
                }
                updateStatusSaklar();
                SimpanStatusSaklar("S5", valueS5);

            }
        });

        btnallon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Jika saklar bernilai 1 maka update ke nilai 0, begitu pula sebaliknya
                if(valueS6.equals("0")){
                    valueS6="1";

                }
                else {
                    valueS6="0";
                }
                updateStatusSaklar();
                SimpanStatusSaklar("S6", valueS6);

            }
        });

        btnalloff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Jika saklar bernilai 1 maka update ke nilai 0, begitu pula sebaliknya
                if(valueS7.equals("0")){
                    valueS7="1";

                }
                else {
                    valueS7="0";
                }
                updateStatusSaklar();
                SimpanStatusSaklar("S7", valueS7);

            }
        });

    }
    private void getStatusSaklar(){

        //ambil semua data dr saklar
        new ApiVolley(this, new JSONObject(), "GET", urlMaster, new ApiVolley.VolleyCallback() {
            @Override
            public void onSuccess(String result) {
                try {
                    JSONObject respon = new JSONObject(result);
                    valueS1=respon.getString("S1");
                    valueS2=respon.getString("S2");
                    valueS3=respon.getString("S3");
                    valueS4=respon.getString("S4");
                    valueS5=respon.getString("S5");
                    valueS6=respon.getString("S6");
                    valueS7=respon.getString("S7");

                    //untuk nyetting warnanya kalo di klik
                    if (valueS1.equals("1")) {
                        btnperangkatA.setBackground(getResources().getDrawable(R.drawable.backgroundlingkaranaktif));
                    }
                    else {
                        btnperangkatA.setBackground(getResources().getDrawable(R.drawable.backgroundlingkaran));
                    }

                    //untuk nyetting warnanya kalo di klik
                    if (valueS2.equals("1")) {
                        btnperangkatB.setBackground(getResources().getDrawable(R.drawable.backgroundlingkaranaktif));
                    }
                    else {
                        btnperangkatB.setBackground(getResources().getDrawable(R.drawable.backgroundlingkaran));
                    }

                    //untuk nyetting warnanya kalo di klik
                    if (valueS3.equals("1")) {
                        btnperangkatC.setBackground(getResources().getDrawable(R.drawable.backgroundlingkaranaktif));
                    }
                    else {
                        btnperangkatC.setBackground(getResources().getDrawable(R.drawable.backgroundlingkaran));
                    }

                    //untuk nyetting warnanya kalo di klik
                    if (valueS4.equals("1")) {
                        btnperangkatD.setBackground(getResources().getDrawable(R.drawable.backgroundlingkaranaktif));
                    }
                    else {
                        btnperangkatD.setBackground(getResources().getDrawable(R.drawable.backgroundlingkaran));
                    }

                    //untuk nyetting warnanya kalo di klik
                    if (valueS5.equals("1")) {
                        btnperangkatE.setBackground(getResources().getDrawable(R.drawable.backgroundlingkaranaktif));
                    }
                    else {
                        btnperangkatE.setBackground(getResources().getDrawable(R.drawable.backgroundlingkaran));
                    }

                    //untuk nyetting warnanya kalo di klik
                    if (valueS6.equals("1")) {
                        btnallon.setBackground(getResources().getDrawable(R.drawable.backgroundlingkaranaktif));
                    }
                    else {
                        btnallon.setBackground(getResources().getDrawable(R.drawable.backgroundlingkaran));
                    }

                    //untuk nyetting warnanya kalo di klik
                    if (valueS7.equals("1")) {
                        btnalloff.setBackground(getResources().getDrawable(R.drawable.backgroundlingkaranaktif));
                    }
                    else {
                        btnalloff.setBackground(getResources().getDrawable(R.drawable.backgroundlingkaran));
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onError(String result) {

            }
        });
    }

    private void updateStatusSaklar ()
    {
        JSONObject jBody = new JSONObject();
        try {
            jBody.put("S1", valueS1);
            jBody.put("S2", valueS2);
            jBody.put("S3", valueS3);
            jBody.put("S4", valueS4);
            jBody.put("S5", valueS5);
            jBody.put("S6", valueS6);
            jBody.put("S7", valueS7);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        new ApiVolley(Home.this, jBody, "PUT", urlMaster, new ApiVolley.VolleyCallback() {
            @Override
            public void onSuccess(String result) {

                Log.d(TAG, "onSuccess: " + result);
                getStatusSaklar();
            }

            @Override
            public void onError(String result) {

                Log.d(TAG, "onSuccess: " + result);
            }
        });

    }


    private void SimpanStatusSaklar (String saklar, String status) //harus diisikan nilai status dan saklarnya
    {
        JSONObject jBody = new JSONObject(); //jBody --> parameter dan value yg dibawa ketika url dieksekusi
        String user=session.getUsername();
        try {
            jBody.put("saklar", saklar);
            jBody.put("status", status);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        new ApiVolley(Home.this, jBody, "GET", urlSimpanStatusSaklar+"?saklar="+saklar+"&status="+status+"&user="+user, new ApiVolley.VolleyCallback() {
            @Override
            public void onSuccess(String result) {

                Log.d(TAG, "onSuccess: " + result);
                try {
                    JSONObject hasil=new JSONObject(result);
                    String status = hasil.getString("status");
                    String message = hasil.getString("message");

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String result) {

                Log.d(TAG, "onSuccess: " + result);
            }
        });

    }
}
